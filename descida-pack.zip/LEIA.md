# Resource pack do Descida

## Fonte da marca
`descida:logo` desenha o logo do Zafriel em dois tamanhos (U+E000 grande, U+E001 pequeno).

## Item custom: Brasa
- `assets/descida/textures/item/brasa.png` — 16x16 com alfa de verdade
- `assets/descida/models/item/brasa.json` — modelo
- `assets/descida/items/brasa.json` — definicao que o componente `item_model` aponta

Dar em jogo:
```
/give <nick> minecraft:diamond[minecraft:item_model="descida:brasa"]
```
Qualquer item base serve; o `item_model` troca so a aparencia. Diamante foi escolhido
porque a pilha vai ate 64 e nao tem durabilidade.

## Minerio de Brasa
`assets/minecraft/textures/block/deepslate_diamond_ore.png` **substitui** a textura do
minerio de diamante de deepslate. Ou seja: colocar `deepslate_diamond_ore` no mundo
mostra o nosso minerio.

Isso e global, e foi escolha consciente pra este teste: os mundos sao void e nao existe
minerio de diamante natural em lugar nenhum do servidor, entao o efeito colateral e zero.
Quando existir um sistema de bloco custom de verdade, isto sai.

## Texturas
Geradas com gpt-image-2 em grade de celulas planas 1024x1024, reduzidas a 16x16 pela COR
MAIS FREQUENTE de cada bloco (media borraria) e quantizadas numa paleta de 11 cores, que e
a ordem de grandeza que a vanilla usa.
