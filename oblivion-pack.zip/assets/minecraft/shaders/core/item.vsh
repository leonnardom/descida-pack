#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
// Oblivion: peca do Ceifador vista pelo proprio dono. Marcada pelo tint constante 0xFEFDFE.
out float oblivionNearHide;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

    vec4 tint = Color;
    oblivionNearHide = 0.0;
    if (ivec3(round(Color.rgb * 255.0)) == ivec3(254, 253, 254)) {
        tint = vec4(1.0, 1.0, 1.0, Color.a);
        oblivionNearHide = 1.0;
    }
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, tint) * sample_lightmap(Sampler2, UV2);

    texCoord0 = UV0;
}
